package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class ClickerService : AccessibilityService() {

    companion object {
        @Volatile var instance: ClickerService? = null
        const val SIZE = 140
        const val TSIZE = 70
    }

    private val handler = Handler(Looper.getMainLooper())
    private val btnViews = HashMap<Int, View>()
    private val tgtViews = HashMap<Int, View>()
    private var runToken = 0
    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    override fun onServiceConnected() {
        instance = this
        Store.load(this)
        Store.edit = true
        render()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopRun()
        removeAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Tap ----------
    fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 30))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- Overlay ----------
    fun render() {
        stopRun()
        removeAll()
        for (b in Store.buttons.values) createViews(b)
        refreshTouch()
    }

    fun refreshMode() {
        stopRun()
        refreshTouch()
    }

    private fun makeView(text: String, color: Int, alpha: Float): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.textSize = 16f
        tv.alpha = alpha
        tv.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        return tv
    }

    private fun params(cx: Float, cy: Float, size: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (cx - size / 2f).toInt()
            y = (cy - size / 2f).toInt()
        }
    }

    private fun createViews(b: Btn) {
        val color = when (b.type) {
            "single" -> Color.parseColor("#E53935")
            "seq" -> Color.parseColor("#1E88E5")
            else -> Color.parseColor("#43A047")
        }
        val v = makeView(b.label, color, 0.75f)
        wm.addView(v, params(b.x, b.y, SIZE))
        attachTouch(v, b, false)
        btnViews[b.id] = v

        if (b.type == "single") {
            val t = makeView("+", Color.parseColor("#FB8C00"), 0.5f)
            wm.addView(t, params(b.tx, b.ty, TSIZE))
            attachTouch(t, b, true)
            tgtViews[b.id] = t
        }
    }

    private fun attachTouch(v: View, b: Btn, isTarget: Boolean) {
        var dx = 0f
        var dy = 0f
        v.setOnTouchListener { _, e ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX - lp.x
                    dy = e.rawY - lp.y
                    if (!Store.edit && !isTarget) startRun(b)
                }
                MotionEvent.ACTION_MOVE -> if (Store.edit) {
                    lp.x = (e.rawX - dx).toInt()
                    lp.y = (e.rawY - dy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (Store.edit) {
                        val cx = lp.x + lp.width / 2f
                        val cy = lp.y + lp.height / 2f
                        if (isTarget) {
                            b.tx = cx; b.ty = cy
                        } else {
                            b.x = cx; b.y = cy
                            if (b.type == "seq") { b.tx = cx; b.ty = cy }
                        }
                        Store.save(this)
                    } else if (!isTarget) {
                        stopRun()
                    }
                }
            }
            true
        }
    }

    // Play mode: seq circles aur target dots touch-through ho jate hain
    private fun refreshTouch() {
        for ((id, v) in btnViews) {
            val b = Store.buttons[id] ?: continue
            val through = !Store.edit && b.type == "seq"
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.flags = baseFlags or (if (through) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            wm.updateViewLayout(v, lp)
        }
        for ((_, v) in tgtViews) {
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.flags = baseFlags or (if (!Store.edit) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            wm.updateViewLayout(v, lp)
        }
    }

    private fun removeAll() {
        for (v in btnViews.values) try { wm.removeView(v) } catch (_: Exception) {}
        for (v in tgtViews.values) try { wm.removeView(v) } catch (_: Exception) {}
        btnViews.clear()
        tgtViews.clear()
    }

    // ---------- Tap engine ----------
    private fun startRun(b: Btn) {
        when (b.type) {
            "single" -> runSingle(b)
            "main" -> runSequence()
        }
    }

    private fun stopRun() {
        runToken++
        handler.removeCallbacksAndMessages(null)
    }

    private fun runSingle(b: Btn) {
        val t = ++runToken
        val interval = (1000 / b.cps.coerceIn(1, Store.MAX_CPS)).toLong()
        val r = object : Runnable {
            override fun run() {
                if (t != runToken) return
                tap(b.tx, b.ty)
                handler.postDelayed(this, interval)
            }
        }
        handler.post(r)
    }

    private fun runSequence() {
        val ids = Store.seq.toList()
        if (ids.isEmpty()) return
        val t = ++runToken
        var i = 0
        var rounds = 0
        val r = object : Runnable {
            override fun run() {
                if (t != runToken) return
                val b = Store.buttons[ids[i]]
                if (b != null) tap(b.tx, b.ty)
                val delay = (b?.delayMs ?: 100).coerceAtLeast(30).toLong()
                i++
                if (i >= ids.size) {
                    i = 0
                    rounds++
                    if (!Store.loop && Store.repeat == 0) return
                    if (Store.repeat > 0 && rounds >= Store.repeat) return
                }
                handler.postDelayed(this, delay)
            }
        }
        handler.post(r)
    }
}
