package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var nameEt: EditText
    private lateinit var cpsText: TextView
    private lateinit var cpsBar: SeekBar
    private lateinit var delayEt: EditText
    private lateinit var loopCb: CheckBox
    private lateinit var repeatEt: EditText
    private lateinit var presetSp: Spinner
    private lateinit var presetEt: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.load(this)
        buildUi()
        refreshPresets()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun LinearLayout.label(t: String) {
        addView(TextView(this@MainActivity).apply { text = t; setPadding(0, dp(14), 0, 0) })
    }

    private fun LinearLayout.button(t: String, cb: () -> Unit) {
        addView(Button(this@MainActivity).apply { text = t; setOnClickListener { cb() } })
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        status = TextView(this)
        root.addView(status)
        root.button("Accessibility settings kholo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        root.label("Button ka naam (A-Z / 0-9, max 3)")
        nameEt = EditText(this).apply { filters = arrayOf(InputFilter.LengthFilter(3)) }
        root.addView(nameEt)

        cpsText = TextView(this).apply { text = "Tap per second: 5"; setPadding(0, dp(14), 0, 0) }
        root.addView(cpsText)
        cpsBar = SeekBar(this).apply {
            max = 9
            progress = 4
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    cpsText.text = "Tap per second: ${p + 1}"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(cpsBar)

        root.button("+ Single tap button") { addBtn("single", 0) }

        root.label("Sequence step ke baad delay (ms)")
        delayEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("100")
        }
        root.addView(delayEt)
        root.button("+ Sequence step (1,2,3...)") {
            val d = delayEt.text.toString().toIntOrNull() ?: 100
            addBtn("seq", d)
        }
        root.button("+ Main button (sequence chalane wala)") { addBtn("main", 0) }
        root.button("Last button hatao") { removeLast() }

        loopCb = CheckBox(this).apply { text = "Loop ON (sequence baar-baar)"; isChecked = Store.loop }
        root.addView(loopCb)
        root.label("Kitni baar repeat (0 = jab tak hold)")
        repeatEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Store.repeat.toString())
        }
        root.addView(repeatEt)

        val editCb = CheckBox(this).apply {
            text = "Edit mode (ON = circle move karo, OFF = hold se chalao)"
            isChecked = true
            setOnCheckedChangeListener { _, on ->
                Store.edit = on
                ClickerService.instance?.refreshMode()
            }
        }
        root.addView(editCb)

        root.button("Apply / Buttons dikhao") { pushConfig() }
        root.button("Sab buttons hatao") {
            Store.buttons.clear(); Store.seq.clear(); Store.nextId = 1
            pushConfig()
        }

        root.label("--- Presets ---")
        presetSp = Spinner(this)
        root.addView(presetSp)
        presetEt = EditText(this).apply { hint = "Preset ka naam" }
        root.addView(presetEt)
        root.button("Save preset") {
            val n = presetEt.text.toString().trim()
            if (n.isNotEmpty()) {
                syncOpts()
                Store.savePreset(this, n)
                refreshPresets()
                toast("Saved: $n")
            }
        }
        root.button("Load preset") {
            val n = selectedPreset()
            if (n != null && Store.loadPreset(this, n)) {
                loopCb.isChecked = Store.loop
                repeatEt.setText(Store.repeat.toString())
                pushConfig()
            }
        }
        root.button("Delete preset") {
            val n = selectedPreset()
            if (n != null) { Store.deletePreset(this, n); refreshPresets() }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun syncOpts() {
        Store.loop = loopCb.isChecked
        Store.repeat = repeatEt.text.toString().toIntOrNull() ?: 0
    }

    private fun addBtn(type: String, delay: Int) {
        val dm = resources.displayMetrics
        val cx = dm.widthPixels * 0.5f
        val cy = dm.heightPixels * 0.25f + Store.buttons.size * 170
        val id = Store.nextId++
        val raw = nameEt.text.toString().trim().uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }
        val fallback = when (type) {
            "seq" -> (Store.seq.size + 1).toString()
            "main" -> "GO"
            else -> id.toString()
        }
        val label = if (raw.isEmpty()) fallback else raw.take(3)
        Store.buttons[id] = Btn(
            id, type, label, cx, cy,
            if (type == "single") cx + 260 else cx, cy,
            (cpsBar.progress + 1).coerceIn(1, Store.MAX_CPS), delay
        )
        if (type == "seq") Store.seq.add(id)
        nameEt.setText("")
        pushConfig()
    }

    private fun removeLast() {
        val last = Store.buttons.keys.lastOrNull() ?: return
        Store.buttons.remove(last)
        Store.seq.remove(last)
        pushConfig()
    }

    private fun pushConfig() {
        syncOpts()
        Store.save(this)
        val s = ClickerService.instance
        if (s == null) toast("Pehle Accessibility me Auto Clicker ON karo") else s.render()
        updateStatus()
    }

    private fun updateStatus() {
        status.text = if (ClickerService.instance != null)
            "Accessibility ON. Buttons: ${Store.buttons.size}"
        else
            "Accessibility OFF. Settings > Accessibility > Installed apps > Auto Clicker > ON karo"
    }

    private fun refreshPresets() {
        presetSp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Store.presetNames(this)
        )
    }

    private fun selectedPreset(): String? = presetSp.selectedItem as? String

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
