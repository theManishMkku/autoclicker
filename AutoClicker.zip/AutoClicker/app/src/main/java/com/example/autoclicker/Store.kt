package com.example.autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Btn(
    val id: Int, val type: String, val label: String,
    var x: Float, var y: Float, var tx: Float, var ty: Float,
    val cps: Int, val delayMs: Int
)

object Store {
    const val MAX_CPS = 10
    val buttons = LinkedHashMap<Int, Btn>()
    var seq = mutableListOf<Int>()
    var loop = true
    var repeat = 0
    var edit = true
    var nextId = 1

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (b in buttons.values) {
            arr.put(
                JSONObject()
                    .put("id", b.id).put("type", b.type).put("label", b.label)
                    .put("x", b.x.toDouble()).put("y", b.y.toDouble())
                    .put("tx", b.tx.toDouble()).put("ty", b.ty.toDouble())
                    .put("cps", b.cps).put("delay", b.delayMs)
            )
        }
        return JSONObject().put("buttons", arr).put("seq", JSONArray(seq))
            .put("loop", loop).put("repeat", repeat)
    }

    fun fromJson(o: JSONObject) {
        buttons.clear()
        seq = mutableListOf()
        nextId = 1
        val arr = o.getJSONArray("buttons")
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val b = Btn(
                j.getInt("id"), j.getString("type"), j.getString("label"),
                j.getDouble("x").toFloat(), j.getDouble("y").toFloat(),
                j.getDouble("tx").toFloat(), j.getDouble("ty").toFloat(),
                j.getInt("cps").coerceIn(1, MAX_CPS), j.getInt("delay")
            )
            buttons[b.id] = b
            if (b.id >= nextId) nextId = b.id + 1
        }
        val s = o.getJSONArray("seq")
        for (i in 0 until s.length()) seq.add(s.getInt(i))
        loop = o.optBoolean("loop", true)
        repeat = o.optInt("repeat", 0)
    }

    private fun prefs(c: Context) = c.getSharedPreferences("ac", Context.MODE_PRIVATE)

    fun save(c: Context) {
        prefs(c).edit().putString("current", toJson().toString()).apply()
    }

    fun load(c: Context) {
        val s = prefs(c).getString("current", null) ?: return
        try { fromJson(JSONObject(s)) } catch (_: Exception) {}
    }

    private fun presets(c: Context): JSONObject =
        try { JSONObject(prefs(c).getString("presets", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun presetNames(c: Context): List<String> = presets(c).keys().asSequence().toList()

    fun savePreset(c: Context, name: String) {
        val o = presets(c)
        o.put(name, toJson())
        prefs(c).edit().putString("presets", o.toString()).apply()
    }

    fun loadPreset(c: Context, name: String): Boolean {
        val p = presets(c).optJSONObject(name) ?: return false
        fromJson(p)
        save(c)
        return true
    }

    fun deletePreset(c: Context, name: String) {
        val o = presets(c)
        o.remove(name)
        prefs(c).edit().putString("presets", o.toString()).apply()
    }
}
